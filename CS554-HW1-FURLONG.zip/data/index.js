module.exports = {
    books: require("./books")
};